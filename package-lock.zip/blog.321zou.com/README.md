# blog.321zou.com


支持两种博客系统
- jekyll ： http://jekyll.321zou.com      https://github.com/yanchangyou/jekyll.321zou.com
- hexo ： http://hexo.321zou.com        https://github.com/yanchangyou/hexo.321zou.com

下面是按照IP随机选择，使用nginx反向代理实现
- http://random.321zou.com

默认是hexo，nginx和hexo共用
- http://blog.321zou.com
